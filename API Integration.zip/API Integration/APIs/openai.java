//This service connects to OpenAI GPT-4o Mini.

@Service
public class OpenAIService {

    private static final String API_KEY = "YOUR_OPENAI_API_KEY";

    public String generateResponse(String userInput) {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI("https://api.openai.com/v1/chat/completions"))
                    .header("Authorization", "Bearer " + API_KEY)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(
                            "{\"model\":\"gpt-4o-mini\", \"messages\":[{\"role\":\"system\", \"content\":\"You are a sales agent.\"}, {\"role\":\"user\", \"content\":\"" + userInput + "\"}]}"))
                    .build();

            HttpResponse<String> response = HttpClient.newHttpClient()
                    .send(request, HttpResponse.BodyHandlers.ofString());

            return new JSONObject(response.body()).getJSONArray("choices")
                    .getJSONObject(0).getJSONObject("message").getString("content");
        } catch (Exception e) {
            e.printStackTrace();
            return "I'm sorry, I didn't understand that.";
        }
    }
}