//Create a REST controller to receive incoming calls.

@RestController
@RequestMapping("/twilio")
public class TwilioController {

    private final TwilioService twilioService;

    public TwilioController(TwilioService twilioService) {
        this.twilioService = twilioService;
    }

    @PostMapping("/incoming")
    public ResponseEntity<String> handleIncomingCall(@RequestParam("From") String from, 
                                                     @RequestParam("CallSid") String callSid) {
        String twimlResponse = twilioService.generateTwimlResponse(callSid);
        return ResponseEntity.ok(twimlResponse);
    }
}

//Twilio Service to Generate TWiML Response

//This service handles the incoming call and directs it to Deepgram for transcription.

@Service
public class TwilioService {

    private static final String DEEPGRAM_TRANSCRIBE_URL = "https://api.deepgram.com/v1/listen";

    public String generateTwimlResponse(String callSid) {
        return "<Response>"
                + "<Say>Hello! Please speak after the beep.</Say>"
                + "<Pause length='1'/>"
                + "<Record action='/twilio/process-recording' maxLength='30'/>"
                + "</Response>";
    }
}

4. Processing Speech-to-Text with Deepgram

When Twilio records the user's voice, it will send the recording to this endpoint.

@RestController
@RequestMapping("/twilio")
public class SpeechToTextController {

    private final DeepgramService deepgramService;
    private final OpenAIService openAIService;
    private final TTSService ttsService;

    public SpeechToTextController(DeepgramService deepgramService, OpenAIService openAIService, TTSService ttsService) {
        this.deepgramService = deepgramService;
        this.openAIService = openAIService;
        this.ttsService = ttsService;
    }

    @PostMapping("/process-recording")
    public ResponseEntity<String> processRecording(@RequestParam("RecordingUrl") String recordingUrl) {
        String transcribedText = deepgramService.transcribeAudio(recordingUrl);
        String aiResponse = openAIService.generateResponse(transcribedText);
        String speechUrl = ttsService.generateSpeech(aiResponse);

        String twimlResponse = "<Response><Play>" + speechUrl + "</Play></Response>";
        return ResponseEntity.ok(twimlResponse);
    }
}