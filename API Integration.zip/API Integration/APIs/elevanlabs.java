//This service converts the AI-generated text to speech.

@Service
public class TTSService {

    private static final String API_KEY = "YOUR_ELEVENLABS_API_KEY";

    public String generateSpeech(String text) {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI("https://api.elevenlabs.io/v1/text-to-speech"))
                    .header("xi-api-key", API_KEY)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(
                            "{\"text\":\"" + text + "\", \"voice\":\"en-US\"}"))
                    .build();

            HttpResponse<String> response = HttpClient.newHttpClient()
                    .send(request, HttpResponse.BodyHandlers.ofString());

            return new JSONObject(response.body()).getString("audio_url");
        } catch (Exception e) {
            e.printStackTrace();
            return "Error generating speech.";
        }
    }
}

w It Works

    Twilio receives an incoming call and triggers /twilio/incoming.
    The user speaks, and Twilio records the audio.
    The recording is sent to Deepgram for transcription.
    The transcribed text is sent to GPT-4o Mini to generate a response.
    The response is sent to ElevenLabs, which converts it to speech.
    The generated speech is played back to the user via Twilio.

This is a basic prototype and can be expanded with:

    Multi-turn conversation history management
    Better error handling and logging
    Real-time streaming instead of waiting for recording completion
