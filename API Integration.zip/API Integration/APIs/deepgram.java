//When Twilio records the user's voice, it will send the recording to this endpoint.

@RestController
@RequestMapping("/twilio")
public class SpeechToTextController {

    private final DeepgramService deepgramService;
    private final OpenAIService openAIService;
    private final TTSService ttsService;

    public SpeechToTextController(DeepgramService deepgramService, OpenAIService openAIService, TTSService ttsService) {
        this.deepgramService = deepgramService;
        this.openAIService = openAIService;
        this.ttsService = ttsService;
    }

    @PostMapping("/process-recording")
    public ResponseEntity<String> processRecording(@RequestParam("RecordingUrl") String recordingUrl) {
        String transcribedText = deepgramService.transcribeAudio(recordingUrl);
        String aiResponse = openAIService.generateResponse(transcribedText);
        String speechUrl = ttsService.generateSpeech(aiResponse);

        String twimlResponse = "<Response><Play>" + speechUrl + "</Play></Response>";
        return ResponseEntity.ok(twimlResponse);
    }
}

// Deepgram API for Speech Transcription

//This class sends the audio recording to Deepgram and gets the transcribed text.

@Service
public class DeepgramService {

    private static final String API_KEY = "YOUR_DEEPGRAM_API_KEY";

    public String transcribeAudio(String audioUrl) {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI("https://api.deepgram.com/v1/listen"))
                    .header("Authorization", "Token " + API_KEY)
                    .POST(HttpRequest.BodyPublishers.ofString("{\"url\":\"" + audioUrl + "\"}"))
                    .build();

            HttpResponse<String> response = HttpClient.newHttpClient()
                    .send(request, HttpResponse.BodyHandlers.ofString());

            return new JSONObject(response.body()).getJSONObject("results").getJSONArray("channels")
                    .getJSONObject(0).getJSONArray("alternatives").getJSONObject(0).getString("transcript");
        } catch (Exception e) {
            e.printStackTrace();
            return "Error transcribing audio.";
        }
    }
}
