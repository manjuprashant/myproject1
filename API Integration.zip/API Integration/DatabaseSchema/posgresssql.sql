CREATE TABLE calls (
    id SERIAL PRIMARY KEY,
    call_sid VARCHAR(50) UNIQUE NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    end_time TIMESTAMP,
    duration INT,
    status VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE conversation_logs (
    id SERIAL PRIMARY KEY,
    call_sid VARCHAR(50) REFERENCES calls(call_sid) ON DELETE CASCADE,
    speaker VARCHAR(10) CHECK (speaker IN ('customer', 'agent')),
    message TEXT NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
