//API to Retrieve Conversations
//For PostgreSQL

@RestController
@RequestMapping("/conversations")
public class ConversationController {
    private final ConversationLogRepository logRepository;
    private final CallRepository callRepository;

    @GetMapping("/{callSid}")
    public ResponseEntity<List<ConversationLog>> getConversation(@PathVariable String callSid) {
        Call call = callRepository.findByCallSid(callSid).orElseThrow();
        return ResponseEntity.ok(logRepository.findByCall(call));
    }
}

//For MongoDB

@RestController
@RequestMapping("/conversations")
public class MongoConversationController {
    private final CallRepository callRepository;

    @GetMapping("/{callSid}")
    public ResponseEntity<Call> getConversation(@PathVariable String callSid) {
        return ResponseEntity.of(callRepository.findById(callSid));
    }
}

Next Steps

    Implement dashboard UI for call logs.
    Add conversation analytics (e.g., sentiment analysis).
    Set up Kafka or RabbitMQ for real-time logging.

Would you like help with deploying t