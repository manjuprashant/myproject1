
{
  "call_sid": "CA1234567890abcdef",
  "customer_phone": "+1234567890",
  "start_time": "2025-03-19T10:00:00Z",
  "end_time": "2025-03-19T10:05:00Z",
  "duration": 300,
  "status": "completed",
  "conversation": [
    {
      "speaker": "customer",
      "message": "Hi, I'm interested in your product.",
      "timestamp": "2025-03-19T10:00:10Z"
    },
    {
      "speaker": "agent",
      "message": "Great! Can I know what you're looking for?",
      "timestamp": "2025-03-19T10:00:15Z"
    }
  ]
}