@Entity
@Table(name = "calls")
public class Call {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String callSid;

    private String customerPhone;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Integer duration;
    private String status;

    @OneToMany(mappedBy = "call", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ConversationLog> conversationLogs = new ArrayList<>();
}

//Conversation Log Entity

@Entity
@Table(name = "conversation_logs")
public class ConversationLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "call_sid", referencedColumnName = "callSid")
    private Call call;

    @Enumerated(EnumType.STRING)
    private Speaker speaker;

    @Column(columnDefinition = "TEXT")
    private String message;

    private LocalDateTime timestamp;
}

public enum Speaker {
    CUSTOMER, AGENT
}