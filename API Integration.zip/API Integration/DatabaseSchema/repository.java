//  call Repository
@Repository
public interface CallRepository extends JpaRepository<Call, Long> {
    Optional<Call> findByCallSid(String callSid);
}

//Conversation Log Repository

@Repository
public interface ConversationLogRepository extends JpaRepository<ConversationLog, Long> {
    List<ConversationLog> findByCall(Call call);
}

//Service to Save Logs

@Service
public class ConversationService {

    private final CallRepository callRepository;
    private final ConversationLogRepository logRepository;

    public ConversationService(CallRepository callRepository, ConversationLogRepository logRepository) {
        this.callRepository = callRepository;
        this.logRepository = logRepository;
    }

    public void logMessage(String callSid, Speaker speaker, String message) {
        Call call = callRepository.findByCallSid(callSid).orElseThrow();
        ConversationLog log = new ConversationLog();
        log.setCall(call);
        log.setSpeaker(speaker);
        log.setMessage(message);
        log.setTimestamp(LocalDateTime.now());
        logRepository.save(log);
    }
}

//Storing Logs in MongoDB (Spring Boot)

//If using MongoDB, define a document instead of SQL tables:

@Document(collection = "calls")
public class Call {
    @Id
    private String callSid;
    private String customerPhone;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Integer duration;
    private String status;

    private List<ConversationEntry> conversation;
}

public class ConversationEntry {
    private String speaker; // "customer" or "agent"
    private String message;
    private LocalDateTime timestamp;
}

//MongoDB Repository

@Repository
public interface CallRepository extends MongoRepository<Call, String> {
}

//Service for MongoDB

@Service
public class MongoConversationService {

    private final CallRepository callRepository;

    public MongoConversationService(CallRepository callRepository) {
        this.callRepository = callRepository;
    }

    public void logMessage(String callSid, String speaker, String message) {
        Call call = callRepository.findById(callSid).orElse(new Call());
        call.setCallSid(callSid);
        call.getConversation().add(new ConversationEntry(speaker, message, LocalDateTime.now()));
        callRepository.save(call);
    }
}

7. API to Retrieve Conversations
For PostgreSQL

@RestController
@RequestMapping("/conversations")
public class ConversationController {
    private final ConversationLogRepository logRepository;
    private final CallRepository callRepository;

    @GetMapping("/{callSid}")
    public ResponseEntity<List<ConversationLog>> getConversation(@PathVariable String callSid) {
        Call call = callRepository.findByCallSid(callSid).orElseThrow();
        return ResponseEntity.ok(logRepository.findByCall(call));
    }
}

For MongoDB

@RestController
@RequestMapping("/conversations")
public class MongoConversationController {
    private final CallRepository callRepository;

    @GetMapping("/{callSid}")
    public ResponseEntity<Call> getConversation(@PathVariable String callSid) {
        return ResponseEntity.of(callRepository.findById(callSid));
    }
}

Next Steps

    Implement dashboard UI for call logs.
    Add conversation analytics (e.g., sentiment analysis).
    Set up Kafka or RabbitMQ for real-time logging.

Would you like help with deploying t